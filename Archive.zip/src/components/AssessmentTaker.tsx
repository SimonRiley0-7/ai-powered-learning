"use client"

// components/AssessmentTaker.tsx
import React, { useState, useEffect } from "react";
import { getAssessmentWithQuestions } from "@/app/actions/assessment";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { evaluateAnswer, getAdaptiveQuestion } from "@/lib/gemini";
import AccessibilityControls from "@/components/AccessibilityControls";

type QuestionType = "mcq" | "descriptive" | "practical" | "viva";

interface Question {
  id: string;
  text: string;
  type: QuestionType;
  options?: string[];
  correctAnswer: string;
  difficulty: "EASY" | "MEDIUM" | "HARD";
  points: number;
}

interface Answer {
  questionId: string;
  userAnswer: string;
  score: number;
  feedback?: string;
  detailedAnalysis?: string;
}

interface AssessmentTakerProps {
  assessmentId: string;
  assessmentTitle: string;
  subject: string;
  isAdaptive: boolean;
  accessibilityFeatures: string[];
  onComplete: (answers: Answer[], totalScore: number) => void;
  /** Multiplier applied to the base assessment duration. Default 1.0. */
  extraTimeMultiplier?: number;
  /** If true, settings are locked by a supervisor – passed down to AccessibilityControls. */
  lockedBySupervisor?: boolean;
  /** Auto-advance to the next question after submission. */
  autoAdvanceQuestions?: boolean;
  /** Read question aloud using Web Speech API when it loads. */
  textToSpeech?: boolean;
}

const AssessmentTaker: React.FC<AssessmentTakerProps> = ({
  assessmentId,
  assessmentTitle,
  subject,
  isAdaptive,
  accessibilityFeatures,
  onComplete,
  extraTimeMultiplier = 1.0,
  lockedBySupervisor = false,
  autoAdvanceQuestions = false,
  textToSpeech = false,
}) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [userAnswer, setUserAnswer] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(3600);
  const [accessibilityEnabled, setAccessibilityEnabled] = useState(
    accessibilityFeatures.length > 0
  );

  // Load questions
  useEffect(() => {
    const loadQuestions = async () => {
      try {
        const assessment = await getAssessmentWithQuestions(assessmentId)
        if (assessment && assessment.questions) {
          const mappedQuestions = assessment.questions.map(q => ({
            id: q.id,
            text: q.text,
            type: q.type.toLowerCase() as QuestionType,
            options: q.options || [],
            correctAnswer: q.correctAnswer,
            difficulty: q.difficulty,
            points: q.points
          }));
          setQuestions(mappedQuestions);
          // Apply extraTimeMultiplier to the assessment duration
          if (assessment.duration) {
            setTimeRemaining(Math.round(assessment.duration * 60 * extraTimeMultiplier));
          }
        }
      } catch (error) {
        console.error("Error loading questions:", error);
      }
    };

    loadQuestions();
  }, [assessmentId, extraTimeMultiplier]);

  // Timer countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 0) {
          clearInterval(timer);
          handleTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [extraTimeMultiplier]);

  const handleTimeUp = () => {
    // Submit whatever answers the user has provided
    const remainingQuestions = questions.slice(currentQuestionIndex);
    const unansweredResponses = remainingQuestions.map((q) => ({
      questionId: q.id,
      userAnswer: "",
      score: 0,
      feedback: "No answer provided",
    }));

    onComplete([...answers, ...unansweredResponses], calculateTotalScore([...answers]));
  };

  const calculateTotalScore = (answersList: Answer[]): number => {
    return answersList.reduce((total, ans) => total + ans.score, 0);
  };

  const handleSubmitAnswer = async () => {
    if (!userAnswer.trim() && questions[currentQuestionIndex].type !== "mcq") {
      alert("Please provide an answer before continuing.");
      return;
    }

    setIsSubmitting(true);
    const currentQuestion = questions[currentQuestionIndex];

    try {
      // Evaluate answer using Gemini API
      const evaluation = await evaluateAnswer(
        currentQuestion.text,
        currentQuestion.correctAnswer,
        userAnswer
      );

      // Calculate normalized score based on question points
      const normalizedScore = (evaluation.score / 100) * currentQuestion.points;

      const newAnswer: Answer = {
        questionId: currentQuestion.id,
        userAnswer,
        score: normalizedScore,
        feedback: evaluation.feedback,
        detailedAnalysis: evaluation.detailedAnalysis,
      };

      const updatedAnswers = [...answers, newAnswer];
      setAnswers(updatedAnswers);

      // If adaptive and not the last question, get a new question based on performance
      if (isAdaptive && currentQuestionIndex < questions.length - 1) {
        const performance = (normalizedScore / currentQuestion.points) * 100;
        const difficulty = performance > 80 ? "hard" : performance > 50 ? "medium" : "easy";

        try {
          const newQuestion = await getAdaptiveQuestion(
            subject,
            difficulty as "easy" | "medium" | "hard",
            performance
          );

          // Add the new question to the list
          const adaptiveQuestion: Question = {
            id: `adaptive-${currentQuestionIndex + 1}`,
            text: newQuestion.question,
            type: newQuestion.type,
            options: newQuestion.options,
            correctAnswer: newQuestion.correctAnswer,
            difficulty: difficulty.toUpperCase() as "EASY" | "MEDIUM" | "HARD",
            points: difficulty === "hard" ? 20 : difficulty === "medium" ? 15 : 10,
          };

          // Replace the next question with our adaptive one
          const updatedQuestions = [...questions];
          updatedQuestions[currentQuestionIndex + 1] = adaptiveQuestion;
          setQuestions(updatedQuestions);
        } catch (error) {
          console.error("Error getting adaptive question:", error);
        }
      }

      if (currentQuestionIndex === questions.length - 1) {
        // Assessment complete
        onComplete(updatedAnswers, calculateTotalScore(updatedAnswers));
      } else if (autoAdvanceQuestions) {
        // Auto-advance to next question
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setUserAnswer("");
      } else {
        // Just stay on current question until user clicks Next
        // Use a small delay or state to show success
      }
    } catch (error) {
      console.error("Error submitting answer:", error);
      alert("There was an error submitting your answer. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderQuestion = () => {
    if (questions.length === 0) return <div>Loading questions...</div>;

    const currentQuestion = questions[currentQuestionIndex];

    return (
      <div className="space-y-4">
        <div className="text-lg font-medium">
          Question {currentQuestionIndex + 1} of {questions.length}
        </div>

        <div className="text-sm text-gray-500">
          Difficulty: {currentQuestion.difficulty} | Points: {currentQuestion.points}
        </div>

        <div className="text-lg">{currentQuestion.text}</div>

        {currentQuestion.type === "mcq" && currentQuestion.options && (
          <div className="space-y-2">
            {currentQuestion.options.map((option, index) => (
              <div key={index} className="flex items-center">
                <input
                  type="radio"
                  id={`option-${index}`}
                  name="mcq-answer"
                  value={option}
                  checked={userAnswer === option}
                  onChange={() => setUserAnswer(option)}
                  className="mr-2"
                />
                <label htmlFor={`option-${index}`}>{option}</label>
              </div>
            ))}
          </div>
        )}

        {currentQuestion.type === "descriptive" && (
          <textarea
            value={userAnswer}
            onChange={(e) => setUserAnswer(e.target.value)}
            className="w-full h-32 p-2 border rounded"
            placeholder="Type your answer here..."
          />
        )}

        {currentQuestion.type === "practical" && (
          <textarea
            value={userAnswer}
            onChange={(e) => setUserAnswer(e.target.value)}
            className="w-full h-48 p-2 border rounded font-mono"
            placeholder="Write your code or solution here..."
          />
        )}

        {currentQuestion.type === "viva" && (
          <div className="space-y-4">
            <textarea
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              className="w-full h-32 p-2 border rounded"
              placeholder="Type your answer here..."
            />
            {accessibilityFeatures.includes("VOICE_TO_TEXT") && (
              <Button
                variant="outline"
                className="flex items-center gap-2"
                onClick={() => alert("Voice recording would start here")}
              >
                <span>🎤</span> Record Answer
              </Button>
            )}
          </div>
        )}
      </div>
    );
  };

  // Auto-read question when it changes if TTS is enabled
  useEffect(() => {
    if (textToSpeech && questions[currentQuestionIndex]) {
      const utterance = new SpeechSynthesisUtterance(questions[currentQuestionIndex].text);
      window.speechSynthesis.cancel(); // Stop any current speech
      window.speechSynthesis.speak(utterance);
    }
  }, [currentQuestionIndex, textToSpeech, questions]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };

  if (questions.length === 0) {
    return <div className="flex justify-center p-8">Loading assessment...</div>;
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>{assessmentTitle}</CardTitle>
          <div className="text-sm text-gray-500">Subject: {subject}</div>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-lg font-medium">Time: {formatTime(timeRemaining)}</div>
          {accessibilityFeatures.length > 0 && (
            <Button
              variant="outline"
              onClick={() => setAccessibilityEnabled(!accessibilityEnabled)}
              className="flex items-center gap-2"
            >
              <span role="img" aria-label="Accessibility">♿</span>
              <span>{accessibilityEnabled ? "Disable" : "Enable"} Accessibility</span>
            </Button>
          )}
        </div>
      </CardHeader>

      <CardContent>
        {accessibilityEnabled && (
          <AccessibilityControls
            features={accessibilityFeatures}
            className="mb-6"
            lockedBySupervisor={lockedBySupervisor}
          />
        )}
        {renderQuestion()}
      </CardContent>

      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          disabled={currentQuestionIndex === 0 || isSubmitting}
          onClick={() => {
            if (currentQuestionIndex > 0) {
              setCurrentQuestionIndex(currentQuestionIndex - 1);
              setUserAnswer(answers[currentQuestionIndex - 1]?.userAnswer || "");
            }
          }}
        >
          Previous
        </Button>
        <Button
          disabled={isSubmitting}
          onClick={handleSubmitAnswer}
        >
          {isSubmitting ? "Submitting..." : currentQuestionIndex === questions.length - 1 ? "Finish" : "Next"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default AssessmentTaker;