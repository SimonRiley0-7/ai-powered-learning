"use server"

import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"

// For Instructors to fetch their created assessments
export async function getInstructorAssessments() {
    const session = await auth()
    if (!session?.user?.id || session.user.role !== 'INSTRUCTOR') throw new Error("Unauthorized")

    return await prisma.assessment.findMany({
        where: {
            users: {
                some: { id: session.user.id }
            }
        },
        include: {
            _count: {
                select: { questions: true, results: true }
            }
        },
        orderBy: { createdAt: 'desc' }
    })
}

// For Candidates to list available assessments
export async function getAvailableAssessments() {
    const session = await auth()
    if (!session?.user?.id) throw new Error("Unauthorized")

    // Normally you'd filter this by enrollment or something, but we'll return all
    return await prisma.assessment.findMany({
        include: {
            _count: { select: { questions: true } }
        },
        orderBy: { createdAt: 'desc' }
    })
}

// For taking an assessment
export async function getAssessmentWithQuestions(assessmentId: string) {
    const session = await auth()
    if (!session?.user?.id) throw new Error("Unauthorized")

    return await prisma.assessment.findUnique({
        where: { id: assessmentId },
        include: {
            questions: true // Fetch questions so we can render them
        }
    })
}
