"use server"

import { prisma } from "@/lib/prisma"
import { auth } from "@/auth"

export async function submitAssessment(assessmentId: string, answers: { questionId: string, answer: string }[]) {
    const session = await auth()
    if (!session?.user?.id) throw new Error("Unauthorized")

    // Verify the assessment exists
    const assessment = await prisma.assessment.findUnique({
        where: { id: assessmentId },
        include: { questions: true }
    })

    if (!assessment) throw new Error("Assessment not found")

    // Basic score calculation (if MCQ)
    let totalScore = 0;
    const processedAnswers = answers.map(ans => {
        const question = assessment.questions.find(q => q.id === ans.questionId)
        // Very rudimentary MCQ scoring
        const isCorrect = question?.type === 'MCQ' && question.correctAnswer === ans.answer
        const score = isCorrect ? (question?.points || 10) : 0
        totalScore += score

        return {
            questionId: ans.questionId,
            userAnswer: ans.answer,
            score: score,
            feedback: isCorrect ? "Correct" : "Incorrect"
        }
    })

    const maxPossiblePoints = assessment.questions.reduce((sum, q) => sum + (q.points || 10), 0)
    const percentage = maxPossiblePoints > 0 ? (totalScore / maxPossiblePoints) * 100 : 0
    const status = percentage >= assessment.passingScore ? "PASSED" : "FAILED"

    // Save the result
    const result = await prisma.result.create({
        data: {
            userId: session.user.id,
            assessmentId: assessment.id,
            totalScore,
            percentage,
            status,
            startedAt: new Date(), // Ideally this is passed from client when they started
            completedAt: new Date(),
            answers: {
                create: processedAnswers
            }
        }
    })

    return { success: true, resultId: result.id, percentage, status }
}

export async function getUserResults() {
    const session = await auth()
    if (!session?.user?.id) throw new Error("Unauthorized")

    return await prisma.result.findMany({
        where: { userId: session.user.id },
        include: {
            assessment: {
                select: {
                    title: true,
                    subject: true,
                    passingScore: true,
                    _count: { select: { questions: true } }
                }
            }
        },
        orderBy: { startedAt: 'desc' }
    })
}
