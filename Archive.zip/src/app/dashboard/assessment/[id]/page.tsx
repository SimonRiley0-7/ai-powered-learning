"use client";

import React, { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import AssessmentTaker from "@/components/AssessmentTaker";
import { getAssessmentWithQuestions } from "@/app/actions/assessment";
import { submitAssessment as submitResults } from "@/app/actions/result";

interface AccessibilityConfig {
    extraTimeMultiplier: number;
    lockedBySupervisor: boolean;
    largeInteractionMode: boolean;
    simplifiedMode: boolean;
    autoAdvanceQuestions: boolean;
    highContrast: boolean;
    textToSpeech: boolean;
    voiceNavigationEnabled: boolean;
}

export default function TakeAssessmentPage() {
    const params = useParams();
    const router = useRouter();
    const assessmentId = params.id as string;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const [assessmentInfo, setAssessmentInfo] = useState<any>(null);
    const [accessibilityConfig, setAccessibilityConfig] = useState<AccessibilityConfig>({
        extraTimeMultiplier: 1.0,
        lockedBySupervisor: false,
        largeInteractionMode: false,
        simplifiedMode: false,
        autoAdvanceQuestions: false,
        highContrast: false,
        textToSpeech: false,
        voiceNavigationEnabled: false,
    });

    useEffect(() => {
        const loadInfo = async () => {
            const data = await getAssessmentWithQuestions(assessmentId);
            if (data) setAssessmentInfo(data);
        };
        loadInfo();

        // Fetch the candidate's accessibility settings
        const loadAccessibility = async () => {
            try {
                const res = await fetch("/api/accessibility/settings");
                if (res.ok) {
                    const json = await res.json() as { settings?: Partial<AccessibilityConfig> };
                    if (json.settings) {
                        setAccessibilityConfig((prev) => ({ ...prev, ...json.settings }));
                    }
                }
            } catch {
                // Settings fetch failure is non-blocking
            }
        };
        loadAccessibility();
    }, [assessmentId]);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const handleAssessmentComplete = async (answers: any[]) => {
        try {
            const formattedAnswers = answers.map(a => ({
                questionId: a.questionId,
                answer: a.userAnswer
            }));
            const result = await submitResults(assessmentId, formattedAnswers);
            if (result.success) {
                router.push("/dashboard");
            }
        } catch (error) {
            console.error("Failed to submit assessment:", error);
            alert("Error submitting assessment. Please try again.");
        }
    };

    if (!assessmentInfo) {
        return <div className="p-8 text-center mt-20 text-muted-foreground">Loading test environment...</div>;
    }

    const accessibilityFeatures = assessmentInfo.accessibilityFeatures || [];

    return (
        <div
            className={[
                "container mx-auto py-12 px-4",
                accessibilityConfig.largeInteractionMode ? "large-interaction" : "",
                accessibilityConfig.simplifiedMode ? "simplified-mode" : "",
                accessibilityConfig.highContrast ? "high-contrast" : "",
            ].filter(Boolean).join(" ")}
        >
            <AssessmentTaker
                assessmentId={assessmentId}
                assessmentTitle={assessmentInfo.title}
                subject={assessmentInfo.subject}
                isAdaptive={assessmentInfo.isAdaptive}
                accessibilityFeatures={accessibilityFeatures}
                onComplete={handleAssessmentComplete}
                extraTimeMultiplier={accessibilityConfig.extraTimeMultiplier}
                lockedBySupervisor={accessibilityConfig.lockedBySupervisor}
                autoAdvanceQuestions={accessibilityConfig.autoAdvanceQuestions}
                textToSpeech={accessibilityConfig.textToSpeech}
            />
        </div>
    );
}
